#ifndef mcp23017_H
#define mcp23017_H
/***************************************************************
Copyright © ALIENTEK Co., Ltd. 1998-2029. All rights reserved.
文件名		: mcp23017reg.h
作者	  	: 左忠凯
版本	   	: V1.0
描述	   	: mcp23017寄存器地址描述头文件
其他	   	: 无
论坛 	   	: www.openedv.com
日志	   	: 初版V1.0 2019/9/2 左忠凯创建
***************************************************************/

#define mcp23017_ADDR    	0X1E	/* mcp23017器件地址  */

/* AP3316C寄存器 */
#define mcp23017_SYSTEMCONG	0x00	/* 配置寄存器       */
#define mcp23017_INTSTATUS	0X01	/* 中断状态寄存器   */
#define mcp23017_INTCLEAR	0X02	/* 中断清除寄存器   */
#define mcp23017_IRDATALOW	0x0A	/* IR数据低字节     */
#define mcp23017_IRDATAHIGH	0x0B	/* IR数据高字节     */
#define mcp23017_ALSDATALOW	0x0C	/* ALS数据低字节    */
#define mcp23017_ALSDATAHIGH	0X0D	/* ALS数据高字节    */
#define mcp23017_PSDATALOW	0X0E	/* PS数据低字节     */
#define mcp23017_PSDATAHIGH	0X0F	/* PS数据高字节     */

#endif

/*--------------------------------------------------------------------------------------   
 * 项目名称:

     MCP23017驱动程序

 * 功能描述:

     1、

 * 版权信息:

     (c) 飞翼电子, 2017.

 * 历史版本:
     2017-06-08:
       - 初始版本 V1.0.0;

 * 配置说明:
     MCU:             AT89S51
     晶振:      	  外部晶振：11.0592MHz
     扩展模块:  	  -
     软件:            Keil.C51.V9.01

 * 备注:
     - 首先在IIC驱动文件中设置通信接口SCL和SDA
	 - 在MCP23017.h文件中设置ITA、ITB、RST所使用的单片机引脚

--------------------------------------------------------------------------------------*/   

#ifndef _MCP23017_H_
#define _MCP23017_H_

//-------------------------------定义MCP017内部寄存器地址------------------------------ 

#define MCP23017_IODIR 			0x00
#define MCP23017_IPOL 			0x02
#define MCP23017_GPINTEN 		0x04
#define MCP23017_DEFVAL 		0x06
#define MCP23017_INTCON 		0x08
#define MCP23017_IOCON 			0x0A
#define MCP23017_GPPU 			0x0C
#define MCP23017_INTF 			0x0E
#define MCP23017_INTCAP 		0x10
#define MCP23017_GPIO 			0x12
#define MCP23017_OLAT 			0x14

//-------------------------------定义辅助宏定义--------------------------------------- 
#define MCP23017_PORTA			0x00
#define MCP23017_PORTB			0x01

//定义输入输出
#define INPUT					0x01
#define OUTPUT					0x00
//定义使能或除能
#define ENABLE					0x01
#define DISABLE					0x00

#define SET						0x01
#define RESET					0x00
//定义是否对端口极性取反
//当设置为取反时，读取的端口状态与实际输入状态极性相反
#define POLARITY_REVERSE		0x01
#define POLARITY_NON_REVERSE	0x00

#define PIN0					0x01
#define PIN1					0x02
#define PIN2					0x04
#define PIN3					0x08
#define PIN4					0x10
#define PIN5					0x20
#define PIN6					0x40
#define PIN7					0x80
#define ALLPIN					0xFF

//定义中断的类型
#define DIS_INTERRUPT			0x00	   //关闭中断
#define HIGHLEVEL_INTERRUPT		0x01	   //高电平中断
#define LOWLEVEL_INTERRUPT		0x02	   //低电平中断
#define CHANGE_INTERRUPT		0x03	   //电平变化中断

//定义INTA、INTB是否关联
#define INTA_INTB_CONJUNCTION	0x00	   //AB关联
#define INTA_INTB_INDEPENDENT	0x01	   //AB独立

//定义硬件地址是否使能
#define HWA_EN					0x00	   //A0、A1、A2、硬件地址使能
#define HWA_DIS					0x01	   //A0、A1、A2、硬件地址禁用，

//定义INTA、INTB引脚的输出类型
#define INT_OD					0x00	   //开漏输出
#define INT_PUSHPULL_HIGH		0x01	   //推挽输出，高电平有效
#define INT_PUSHPULL_LOW		0x02	   //推挽输出，低电平有效


//----------------------------------函数原型-------------------------------------------   
//初始化指定地址的MCP23017器件
unsigned short MCP23017_INIT(unsigned char deviceAddr,unsigned char intab,unsigned char hwa,unsigned char o);
//设置制定地址的MCP23017的指定端口的指定引脚为输入或输出状态
unsigned short MCP23017_IO_DIR(unsigned char deviceAddr,unsigned char port,unsigned char pin,unsigned char dir);
//设置指定地址的MCP23017的指定端口的指定引脚是否开启上拉电阻
unsigned short MCP23017_IO_PU(unsigned char deviceAddr,unsigned char port,unsigned char pin,unsigned char pu);
//设置指定地址的MCP23017的指定端口的指定引脚是否对端口极性取反
unsigned short MCP23017_IO_POLARITY(unsigned char deviceAddr,unsigned char port,unsigned char pin,unsigned char polarity);
//设置指定地址的MCP23017的指定端口的指定引脚是否开启中断功能及中断的类型
unsigned short MCP23017_IO_INT(unsigned char deviceAddr,unsigned char port,unsigned char pin,unsigned char intKind);
//读取指定地址的MCP23017的指定端口的中断标志寄存器
unsigned char MCP23017_READ_INTF(unsigned char deviceAddr,unsigned char port);
//读取指定地址的MCP23017的指定端口发生中断时中断捕捉寄存器捕捉到的端口值
unsigned char MCP23017_READ_INTCAP(unsigned char deviceAddr,unsigned char port);
//读取指定地址的MCP23017的指定端口值
unsigned char MCP23017_READ_GPIO(unsigned char deviceAddr,unsigned char port);
//向指定地址的MCP23017的指定端口写值
unsigned short MCP23017_WRITE_GPIO(unsigned char deviceAddr,unsigned char port,unsigned char val);
//设置指定地址的MCP23017的指定端口的指定引脚
unsigned short MCP23017_SET_GPIO_PIN(unsigned char deviceAddr,unsigned char port,unsigned char pin,unsigned char s);
//读取指定地址的MCP23017的指定端口的输出锁存寄存器
unsigned char MCP23017_READ_OLAT(unsigned char deviceAddr,unsigned char port);
//写指定地址的MCP23017的指定端口的输出锁存寄存器
unsigned short MCP23017_WRITE_OLAT(unsigned char deviceAddr,unsigned char port,unsigned char val);
//从指定地址的MCP23017器件的指定寄存器读一字节数据
unsigned short I2C_Read_Byte_MCP23017(unsigned char deviceAddr, unsigned char regAddress, unsigned char* recv);
//向指定地址的MCP23017器件的指定寄存器写一字节数据
unsigned short I2C_Write_Byte_MCP23017(unsigned char deviceAddr, unsigned char regAddress, unsigned char content);

#endif

/*-------------------------------------结束------------------------------------------*/   
